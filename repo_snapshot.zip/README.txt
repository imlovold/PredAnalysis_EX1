This is a streamlit app for visualizing data exploration for heart disease prediction.
The streamlit setup code (gitignore and dev container) is based on a template (gdp-dashboard) from streamlit.


In Bash:
pip install -r requirements.txt
python -m streamlit run Data_Explorer.py